
#include "IBacklightService.h"
#include "BpBacklightService.h"


IMPLEMENT_META_INTERFACE(BacklightService, "com.lge.Backlight")
